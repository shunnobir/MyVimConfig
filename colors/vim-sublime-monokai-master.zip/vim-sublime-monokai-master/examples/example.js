import * as bleh from 'bleh';

function test(stuff) {
	super(stuff.andThings);
	this.blarg = things;
	Array.indexOf('one');

	var baloney = (b, e) => {
		asdf();
		return 2;
	};

	var meh = function() {};

	Array.prototype.bleh = function() {
		console.log('stuff and things!');
	};

	var object = {
		derp() {
			return "WHAT?";
		}
	};

	let anotherThing = undefined;
	var hmm = null;
	var regex = /\x02\t(?:asdf)|wat|\bstuff+|things\23[0-9]/g;
}

export default test;
